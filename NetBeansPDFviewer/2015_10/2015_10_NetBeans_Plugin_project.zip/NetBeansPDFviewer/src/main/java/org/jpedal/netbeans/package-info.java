/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
@TemplateRegistration(folder = "Other", content = "PDFTemplate.PDF")
package org.jpedal.netbeans;

import org.netbeans.api.templates.TemplateRegistration;
